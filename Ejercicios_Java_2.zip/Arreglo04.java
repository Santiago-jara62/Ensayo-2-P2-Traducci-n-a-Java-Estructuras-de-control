/**
 *
 * @author SANTIAGO JARA
 */
import java.util.Scanner;

public class Arreglo04 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int[] numeros = new int[20];

        int cantidadPares = 0;
        int cantidadImpares = 0;
        int sumaPares = 0;
        int sumaImpares = 0;

        for (int i = 0; i < numeros.length; i++) {
            System.out.print("Ingrese el número entero " + (i + 1) + " de 20: ");
            numeros[i] = sc.nextInt();
        }

        // Se recorre el arreglo clasificando cada número
        for (int i = 0; i < numeros.length; i++) {
            if (numeros[i] % 2 == 0) {
                cantidadPares++;
                sumaPares += numeros[i];
            } else {
                cantidadImpares++;
                sumaImpares += numeros[i];
            }
        }

        System.out.println();
        System.out.println("Cantidad de números pares: " + cantidadPares);
        System.out.println("Cantidad de números impares: " + cantidadImpares);
        System.out.println("Suma de los pares: " + sumaPares);
        System.out.println("Suma de los impares: " + sumaImpares);

        sc.close();
    }
}
