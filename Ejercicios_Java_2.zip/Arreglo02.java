/**
 *
 * @author SANTIAGO JARA
 */
import java.util.Scanner;

public class Arreglo02 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        double[] numeros = new double[10];
        double suma = 0;

        for (int i = 0; i < numeros.length; i++) {
            System.out.print("Ingrese el número real " + (i + 1) + " de 10: ");
            // Se lee como texto y se cambia la coma por punto,
            // así funciona escribiendo 2.5 o 2,5
            numeros[i] = Double.parseDouble(sc.next().replace(',', '.'));
            suma += numeros[i];
        }

        double promedio = suma / numeros.length;

        System.out.println();
        System.out.println("Suma total: " + suma);
        System.out.println("Promedio: " + promedio);

        sc.close();
    }
}
