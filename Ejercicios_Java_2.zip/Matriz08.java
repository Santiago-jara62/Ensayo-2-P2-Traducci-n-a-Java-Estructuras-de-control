/**
 *
 * @author SANTIAGO JARA
 */
import java.util.Scanner;

public class Matriz08 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int[][] matriz = new int[4][4];

        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                System.out.print("Ingrese el elemento [" + i + "][" + j + "]: ");
                matriz[i][j] = sc.nextInt();
            }
        }

        // La diagonal principal son los elementos donde fila y columna son iguales
        int sumaDiagonal = 0;

        System.out.println();
        System.out.println("===== DIAGONAL PRINCIPAL =====");
        for (int i = 0; i < 4; i++) {
            System.out.println("Elemento [" + i + "][" + i + "]: " + matriz[i][i]);
            sumaDiagonal += matriz[i][i];
        }

        System.out.println();
        System.out.println("Suma de la diagonal principal: " + sumaDiagonal);

        sc.close();
    }
}
