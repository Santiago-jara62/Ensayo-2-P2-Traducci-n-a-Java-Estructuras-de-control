/**
 *
 * @author SANTIAGO JARA
 */
import java.util.Scanner;

public class Matriz06 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int[][] matriz = new int[3][4];

        // El ciclo de afuera recorre las filas y el de adentro las columnas
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 4; j++) {
                System.out.print("Ingrese el elemento [" + i + "][" + j + "]: ");
                matriz[i][j] = sc.nextInt();
            }
        }

        System.out.println();
        System.out.println("===== MATRIZ 3 x 4 =====");
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 4; j++) {
                System.out.print(matriz[i][j] + "\t");
            }
            System.out.println(); // salto de línea al terminar cada fila
        }

        sc.close();
    }
}
