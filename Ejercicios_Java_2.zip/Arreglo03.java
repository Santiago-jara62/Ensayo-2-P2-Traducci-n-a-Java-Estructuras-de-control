/**
 *
 * @author SANTIAGO JARA
 */
import java.util.Scanner;

public class Arreglo03 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int[] numeros = new int[15];

        for (int i = 0; i < numeros.length; i++) {
            System.out.print("Ingrese el número entero " + (i + 1) + " de 15: ");
            numeros[i] = sc.nextInt();
        }

        // El primer elemento es, por ahora, el mayor y el menor
        int mayor = numeros[0];
        int menor = numeros[0];
        int posicionMayor = 0;
        int posicionMenor = 0;

        for (int i = 1; i < numeros.length; i++) {
            if (numeros[i] > mayor) {
                mayor = numeros[i];
                posicionMayor = i;
            }
            if (numeros[i] < menor) {
                menor = numeros[i];
                posicionMenor = i;
            }
        }

        System.out.println();
        System.out.println("Número mayor: " + mayor);
        System.out.println("Número menor: " + menor);
        System.out.println("Posición del mayor: " + posicionMayor);
        System.out.println("Posición del menor: " + posicionMenor);

        sc.close();
    }
}
