/**
 *
 * @author SANTIAGO JARA
 */
import java.util.Scanner;

public class Arreglo05 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int[] numeros = new int[12];

        for (int i = 0; i < numeros.length; i++) {
            int numero;

            // Se repite la pregunta hasta que el número sea positivo
            do {
                System.out.print("Ingrese el número positivo para la posición " + i + ": ");
                numero = sc.nextInt();

                if (numero <= 0) {
                    System.out.println("Debe ser un número positivo. Intente de nuevo.");
                }
            } while (numero <= 0);

            // Antes de guardarlo se le suma el índice de la posición
            numeros[i] = numero + i;
        }

        System.out.println();
        System.out.println("===== ARREGLO MODIFICADO =====");
        for (int i = 0; i < numeros.length; i++) {
            System.out.println("Posición " + i + ": " + numeros[i]);
        }

        sc.close();
    }
}
