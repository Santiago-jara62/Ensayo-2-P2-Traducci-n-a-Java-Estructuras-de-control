/**
 *
 * @author SANTIAGO JARA
 */
import java.util.Scanner;

public class Arreglo01 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int[] numeros = new int[10];

        // Ingreso de los 10 números
        for (int i = 0; i < numeros.length; i++) {
            System.out.print("Ingrese el número para la posición " + i + ": ");
            numeros[i] = sc.nextInt();
        }

        // Visualización indicando la posición
        System.out.println();
        System.out.println("===== VALORES ALMACENADOS =====");
        for (int i = 0; i < numeros.length; i++) {
            System.out.println("Posición " + i + ": " + numeros[i]);
        }

        sc.close();
    }
}
