/**
 *
 * @author SANTIAGO JARA
 */
import java.util.Scanner;

public class Matriz09 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int[][] matriz = new int[5][5];

        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                System.out.print("Ingrese el elemento [" + i + "][" + j + "]: ");
                matriz[i][j] = sc.nextInt();
            }
        }

        // Se parte del primer elemento y se compara contra todos los demás
        int mayor = matriz[0][0];
        int menor = matriz[0][0];

        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                if (matriz[i][j] > mayor) {
                    mayor = matriz[i][j];
                }
                if (matriz[i][j] < menor) {
                    menor = matriz[i][j];
                }
            }
        }

        System.out.println();
        System.out.println("Mayor valor: " + mayor);
        System.out.println("Menor valor: " + menor);

        sc.close();
    }
}
