/**
 *
 * @author SANTIAGO JARA
 */
import java.util.Scanner;

public class Matriz07 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int[][] matriz = new int[4][4];
        int suma = 0;

        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                System.out.print("Ingrese el elemento [" + i + "][" + j + "]: ");
                matriz[i][j] = sc.nextInt();
                suma += matriz[i][j]; // se va acumulando cada elemento
            }
        }

        System.out.println();
        System.out.println("Suma total de todos los elementos: " + suma);

        sc.close();
    }
}
