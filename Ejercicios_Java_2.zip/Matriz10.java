/**
 *
 * @author SANTIAGO JARA
 */
import java.util.Scanner;

public class Matriz10 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int[][] matriz = new int[3][5];

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 5; j++) {
                System.out.print("Ingrese el número para Fila " + i + " y Columna " + j + ": ");
                int numero = sc.nextInt();

                // Se aplica la operación antes de guardar: número + (fila x columna)
                matriz[i][j] = numero + (i * j);
            }
        }

        System.out.println();
        System.out.println("===== MATRIZ RESULTANTE 3 x 5 =====");
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 5; j++) {
                System.out.print(matriz[i][j] + "\t");
            }
            System.out.println();
        }

        sc.close();
    }
}
