/**
 *
 * @author SANTIAGO JARA
 */
import java.util.Scanner;

public class Ejercicio07 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int cantidad = 0;
        int suma = 0;

        System.out.print("Ingrese un número positivo (negativo para terminar): ");
        int numero = sc.nextInt();

        while (numero >= 0) {
            cantidad++;
            suma += numero;

            System.out.print("Ingrese un número positivo (negativo para terminar): ");
            numero = sc.nextInt();
        }

        System.out.println();
        System.out.println("Cantidad de números ingresados: " + cantidad);
        System.out.println("Suma total: " + suma);

        sc.close();
    }
}
