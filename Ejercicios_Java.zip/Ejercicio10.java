/**
 *
 * @author SANTIAGO JARA
 */
import java.util.Scanner;

public class Ejercicio10 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int suma = 0;

        for (int i = 1; i <= 10; i++) {
            System.out.print("Ingrese el número entero " + i + " de 10: ");
            int numero = sc.nextInt();
            suma += numero;
        }

        double promedio = (double) suma / 10;

        System.out.println();
        System.out.println("Suma: " + suma);
        System.out.println("Promedio: " + promedio);

        sc.close();
    }
}
