/**
 *
 * @author SANTIAGO JARA
 */
import java.util.Scanner;

public class Ejercicio08 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        final String CONTRASENA_CORRECTA = "java2026";
        String contrasena;

        do {
            System.out.print("Ingrese la contraseña: ");
            contrasena = sc.nextLine();

            if (!contrasena.equals(CONTRASENA_CORRECTA)) {
                System.out.println("Contraseña incorrecta. Intente de nuevo.");
            }
        } while (!contrasena.equals(CONTRASENA_CORRECTA));

        System.out.println("Acceso concedido.");

        sc.close();
    }
}
