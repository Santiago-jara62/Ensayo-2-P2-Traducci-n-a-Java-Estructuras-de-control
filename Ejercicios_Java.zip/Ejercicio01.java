/**
 *
 * @author SANTIAGO JARA
 */
import java.util.Locale;
import java.util.Scanner;

public class Ejercicio01 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.US); // los decimales se escriben con punto (1.75)

        System.out.print("Ingrese su nombre: ");
        String nombre = sc.nextLine();

        System.out.print("Ingrese su edad: ");
        int edad = sc.nextInt();
        sc.nextLine(); // limpiar el salto de línea pendiente

        System.out.print("Ingrese su carrera: ");
        String carrera = sc.nextLine();

        System.out.print("Ingrese su estatura en metros (ejemplo 1.75): ");
        double estatura = sc.nextDouble();

        System.out.println();
        System.out.println("===== DATOS INGRESADOS =====");
        System.out.println("Nombre: " + nombre);
        System.out.println("Edad: " + edad + " años");
        System.out.println("Carrera: " + carrera);
        System.out.println("Estatura: " + estatura + " m");

        sc.close();
    }
}
