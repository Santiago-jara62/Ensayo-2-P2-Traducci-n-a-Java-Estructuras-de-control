/**
 *
 * @author SANTIAGO JARA
 */
import java.util.Locale;
import java.util.Scanner;

public class Ejercicio11 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.US); // los decimales se escriben con punto (3.5)

        System.out.print("Ingrese el número 1 de 10: ");
        double numero = sc.nextDouble();

        // el primer número es, por ahora, el mayor y el menor
        double mayor = numero;
        double menor = numero;

        for (int i = 2; i <= 10; i++) {
            System.out.print("Ingrese el número " + i + " de 10: ");
            numero = sc.nextDouble();

            if (numero > mayor) {
                mayor = numero;
            }
            if (numero < menor) {
                menor = numero;
            }
        }

        System.out.println();
        System.out.println("Número mayor: " + mayor);
        System.out.println("Número menor: " + menor);

        sc.close();
    }
}
